var dataAry = [
    {name: "周辉", age: 24, score: 90, sex: 0},
    {name: "程瑞杰", age: 20, score: 99, sex: 0},
    {name: "王洁", age: 22, score: 92, sex: 1},
    {name: "杨玲玲", age: 25, score: 96, sex: 1},
    {name: "刘影", age: 20, score: 90, sex: 1},
    {name: "信永亮", age: 23, score: 60, sex: 0}
];