var dataAry = [
    {"name": "李赟", "age": 23, "score": 88},
    {"name": "侯春璐", "age": 19},
    {"name": "王慧", "age": 20, "score": 92},
    {"name": "李占杰", "age": 48, "score": 84},
    {"name": "边东策", "age": 22, "score": 90},
    {"name": "白晓燕", "age": 20, "score": 96},
    {"name": "曹易贤", "age": 39, "score": 63},
    {"name": "周辉", "age": 16, "score": 61},
    {"name": "王巧玲", "age": 24, "score": 82},
    {"name": "刘松松", "age": 19, "score": 100}
];